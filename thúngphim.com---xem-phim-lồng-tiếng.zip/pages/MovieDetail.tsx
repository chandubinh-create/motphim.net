
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MovieService } from '../services/movieService';
import { GeminiService } from '../services/geminiService';
import { Movie, Episode } from '../types';

export const MovieDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const [data, setData] = useState<{ movie: Movie; episodes: Episode[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [aiSummary, setAiSummary] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      if (!slug) return;
      setLoading(true);
      try {
        const result = await MovieService.getMovieDetail(slug);
        setData(result);
        
        // Fetch AI Summary in background
        GeminiService.summarizeMovie(result.movie.name, result.movie.content).then(summary => {
            setAiSummary(summary);
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [slug]);

  if (loading || !data) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  const { movie, episodes = [] } = data;

  return (
    <div className="relative pb-20">
      {/* Backdrop */}
      <div className="absolute top-0 left-0 w-full h-[60vh] overflow-hidden">
        <img src={MovieService.getImageUrl(movie?.poster_url)} className="w-full h-full object-cover blur-2xl opacity-20 scale-110" alt="backdrop" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] to-transparent" />
      </div>

      <div className="max-w-[1320px] mx-auto px-4 relative pt-32">
        <div className="flex flex-col md:flex-row gap-12">
          {/* Left: Poster */}
          <div className="w-full md:w-80 shrink-0">
            <div className="sticky top-24 space-y-6">
              <div className="rounded-2xl overflow-hidden shadow-2xl border border-white/10 ring-1 ring-white/5">
                <img src={MovieService.getImageUrl(movie?.poster_url || movie?.thumb_url)} className="w-full h-auto object-cover" alt={movie?.name} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Link 
                  to={`/watch/${movie?.slug}/1`}
                  className="col-span-2 flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-red-600/30"
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.333-5.89a1.5 1.5 0 000-2.538L6.3 2.841z" /></svg>
                  XEM PHIM
                </Link>
                <button className="flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-700 text-white py-3 rounded-xl border border-gray-700 transition-all">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
                  YÊU THÍCH
                </button>
                <button className="flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-700 text-white py-3 rounded-xl border border-gray-700 transition-all">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>
                  CHIA SẺ
                </button>
              </div>
            </div>
          </div>

          {/* Right: Info */}
          <div className="flex-grow space-y-10">
            <div className="space-y-4">
              <nav className="text-gray-500 text-sm flex items-center gap-2">
                <Link to="/" className="hover:text-white">Trang chủ</Link>
                <span>/</span>
                <span className="text-red-500">{movie?.name}</span>
              </nav>
              <h1 className="text-4xl md:text-6xl font-black text-white leading-tight">{movie?.name}</h1>
              <h2 className="text-xl text-gray-500 font-medium italic">{movie?.origin_name} ({movie?.year})</h2>
              
              <div className="flex flex-wrap gap-3 py-2">
                {movie?.category?.map(cat => (
                  <span key={cat.slug} className="bg-gray-800/80 text-gray-300 px-4 py-1.5 rounded-full text-sm border border-gray-700">
                    {cat.name}
                  </span>
                ))}
                <span className="bg-red-600/20 text-red-500 border border-red-600/30 px-4 py-1.5 rounded-full text-sm">
                   {movie?.quality} {movie?.lang}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 p-6 bg-gray-900/50 rounded-2xl border border-gray-800">
              <div className="space-y-1">
                <span className="text-xs text-gray-500 uppercase font-bold tracking-widest">Thời lượng</span>
                <p className="text-white font-medium">{movie?.time || 'N/A'}</p>
              </div>
              <div className="space-y-1">
                <span className="text-xs text-gray-500 uppercase font-bold tracking-widest">Quốc gia</span>
                <p className="text-white font-medium">{movie?.country?.[0]?.name || 'Đang cập nhật'}</p>
              </div>
              <div className="space-y-1">
                <span className="text-xs text-gray-500 uppercase font-bold tracking-widest">Năm phát hành</span>
                <p className="text-white font-medium">{movie?.year}</p>
              </div>
              <div className="space-y-1">
                <span className="text-xs text-gray-500 uppercase font-bold tracking-widest">Tình trạng</span>
                <p className="text-red-500 font-bold">{movie?.episode_current}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <h3 className="text-xl font-bold text-white uppercase tracking-wider">Nội dung phim</h3>
                {aiSummary && (
                  <span className="text-[10px] bg-gradient-to-r from-purple-600 to-blue-600 text-white px-2 py-0.5 rounded font-bold">AI GENERATED</span>
                )}
              </div>
              <div className="text-gray-400 leading-relaxed text-lg space-y-4">
                {aiSummary ? (
                   <p className="italic text-gray-300 border-l-2 border-red-600 pl-4">{aiSummary}</p>
                ) : (
                  <div dangerouslySetInnerHTML={{ __html: movie?.content || '' }} />
                )}
              </div>
            </div>

            {episodes && episodes.length > 0 && (
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <h3 className="text-xl font-bold text-white uppercase tracking-wider">Danh sách tập</h3>
                  <span className="text-gray-500 text-sm">({movie?.episode_current})</span>
                </div>
                {episodes.map((server, idx) => (
                  <div key={idx} className="space-y-4 bg-gray-900/30 p-6 rounded-2xl border border-gray-800">
                    <p className="text-sm font-bold text-gray-500 uppercase">{server?.server_name}</p>
                    <div className="flex flex-wrap gap-2">
                      {server?.server_data?.map((ep, eIdx) => (
                        <Link
                          key={eIdx}
                          to={`/watch/${movie?.slug}/${ep.name}`}
                          className="min-w-[50px] px-4 py-2 bg-gray-800 hover:bg-red-600 text-white text-center rounded-lg transition-all font-medium border border-gray-700 hover:border-red-500"
                        >
                          {ep.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            <div className="pt-10">
               <h3 className="text-xl font-bold text-white uppercase tracking-wider mb-6">Thông tin khác</h3>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm">
                  <div className="space-y-2">
                    <p className="text-gray-500 font-bold">ĐẠO DIỄN</p>
                    <p className="text-white">{(Array.isArray(movie?.director) ? movie.director.join(', ') : movie?.director) || 'Đang cập nhật'}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-gray-500 font-bold">DIỄN VIÊN</p>
                    <p className="text-white leading-loose">{(Array.isArray(movie?.actor) ? movie.actor.join(', ') : movie?.actor) || 'Đang cập nhật'}</p>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
