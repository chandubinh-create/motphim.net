
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { MovieService } from '../services/movieService';
import { Movie } from '../types';
import { MovieCard } from '../components/MovieCard';

const FILTERS = {
  categories: [
    { name: 'Hành Động', slug: 'hanh-dong' },
    { name: 'Tình Cảm', slug: 'tinh-cam' },
    { name: 'Cổ Trang', slug: 'co-trang' },
    { name: 'Hài Hước', slug: 'hai-huoc' },
    { name: 'Kinh Dị', slug: 'kinh-di' },
    { name: 'Viễn Tưởng', slug: 'vien-tuong' },
  ],
  years: [2024, 2023, 2022, 2021, 2020, 2019],
  types: [
    { name: 'Phim Bộ', slug: 'series' },
    { name: 'Phim Lẻ', slug: 'single' },
  ]
};

export const Search = () => {
  const [results, setResults] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [keyword, setKeyword] = useState('');
  const location = useLocation();
  const navigate = useNavigate();
  
  const queryParams = new URLSearchParams(location.search);
  const q = queryParams.get('q') || '';

  useEffect(() => {
    setKeyword(q);
    const fetchResults = async () => {
      setLoading(true);
      try {
        let movies: Movie[] = [];
        if (q) {
          movies = await MovieService.searchMovies(q);
        } else {
          // Nếu không có keyword, lấy phim mới nhất làm gợi ý
          const res = await MovieService.getLatestMovies(1);
          movies = res.items;
        }
        setResults(movies);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchResults();
  }, [q]);

  const handleManualSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (keyword.trim()) {
      navigate(`/search?q=${encodeURIComponent(keyword)}`);
    }
  };

  return (
    <div className="pt-32 pb-20 min-h-screen">
      <div className="max-w-[1320px] mx-auto px-4">
        
        {/* Search Header & Input */}
        <div className="max-w-3xl mx-auto mb-16 text-center space-y-8">
          <h2 className="text-4xl md:text-5xl font-black text-white tracking-tighter uppercase">
            {q ? 'KẾT QUẢ TÌM KIẾM' : 'KHÁM PHÁ KHO PHIM'}
          </h2>
          
          <form onSubmit={handleManualSearch} className="relative">
            <input 
              type="text" 
              placeholder="Nhập tên phim, đạo diễn hoặc diễn viên..."
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              className="w-full bg-white/5 border border-white/10 text-white rounded-2xl py-5 px-8 pr-16 focus:outline-none focus:ring-2 focus:ring-red-600/50 text-lg transition-all focus:bg-white/10"
            />
            <button type="submit" className="absolute right-4 top-3.5 bg-red-600 hover:bg-red-700 text-white p-2.5 rounded-xl transition-all">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
          </form>

          {/* Quick Filter Tags */}
          <div className="flex flex-wrap justify-center gap-3">
             <span className="text-gray-500 text-xs font-bold uppercase tracking-widest mr-2 self-center">Gợi ý:</span>
             {FILTERS.categories.slice(0, 4).map(cat => (
               <button 
                key={cat.slug} 
                onClick={() => navigate(`/search?q=${cat.name}`)}
                className="text-[10px] font-black tracking-widest bg-white/5 border border-white/10 hover:border-red-600/50 hover:text-white text-gray-400 px-4 py-2 rounded-full transition-all uppercase"
               >
                 {cat.name}
               </button>
             ))}
          </div>
        </div>

        {/* Results Info */}
        <div className="flex items-center justify-between mb-10 pb-6 border-b border-white/5">
           <div className="flex items-center gap-4">
              <div className="w-1.5 h-6 bg-red-600 rounded-full" />
              <h3 className="text-xl font-bold text-white uppercase tracking-tight">
                {q ? `Tìm thấy ${results.length} kết quả cho "${q}"` : 'Phim gợi ý cho bạn'}
              </h3>
           </div>
           
           <div className="hidden md:flex items-center gap-4">
              <select className="bg-gray-900 text-gray-400 text-xs font-bold py-2 px-4 rounded-lg border border-gray-800 focus:outline-none">
                 <option>Sắp xếp: Mới nhất</option>
                 <option>Sắp xếp: Xem nhiều</option>
                 <option>Sắp xếp: Đánh giá</option>
              </select>
           </div>
        </div>

        {/* Results Grid */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-32 gap-4">
             <div className="w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full animate-spin" />
             <p className="text-gray-500 font-bold tracking-widest text-xs uppercase">Đang truy xuất dữ liệu...</p>
          </div>
        ) : results.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-6 gap-y-10 animate-in fade-in duration-500">
            {results.map(movie => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>
        ) : (
          <div className="text-center py-32 space-y-6 bg-white/5 rounded-[40px] border border-dashed border-white/10">
             <div className="text-8xl opacity-10 font-black">404</div>
             <div className="space-y-2">
                <p className="text-xl font-bold text-white">Rất tiếc, không tìm thấy kết quả nào.</p>
                <p className="text-gray-500 max-w-md mx-auto">Thử tìm kiếm với từ khóa khác hoặc duyệt qua các thể loại phổ biến của chúng tôi.</p>
             </div>
             <button 
              onClick={() => navigate('/')} 
              className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-xl font-bold transition-all uppercase text-sm"
             >
               Quay lại trang chủ
             </button>
          </div>
        )}
      </div>
    </div>
  );
};
