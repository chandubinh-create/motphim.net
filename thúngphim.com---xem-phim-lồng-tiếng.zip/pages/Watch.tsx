
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MovieService } from '../services/movieService';
import { Movie, Episode } from '../types';

export const Watch = () => {
  const { slug, episode } = useParams<{ slug: string; episode: string }>();
  const [data, setData] = useState<{ movie: Movie; episodes: Episode[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentEp, setCurrentEp] = useState<any>(null);
  const [activeServerIdx, setActiveServerIdx] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      if (!slug) return;
      setLoading(true);
      try {
        const result = await MovieService.getMovieDetail(slug);
        
        // Sắp xếp server: Ưu tiên lồng tiếng lên đầu
        if (result.episodes) {
          result.episodes.sort((a, b) => {
            const isALongTieng = a.server_name.toLowerCase().includes('lồng tiếng');
            const isBLongTieng = b.server_name.toLowerCase().includes('lồng tiếng');
            return isALongTieng === isBLongTieng ? 0 : isALongTieng ? -1 : 1;
          });
        }
        
        setData(result);
        
        const server = result.episodes && result.episodes.length > activeServerIdx ? result.episodes[activeServerIdx] : (result.episodes?.[0] || null);
        const serverData = server?.server_data || [];
        const found = serverData.find(e => e.name === episode);
        setCurrentEp(found || serverData[0] || null);
        
        // Save to History
        if (result.movie) {
          const history = JSON.parse(localStorage.getItem('thungphim_history') || '[]');
          const existing = history.findIndex((h: any) => h.slug === slug);
          const newItem = {
            slug,
            name: result.movie.name,
            episode: episode,
            poster: MovieService.getImageUrl(result.movie.thumb_url),
            updatedAt: Date.now()
          };
          if (existing > -1) history.splice(existing, 1);
          history.unshift(newItem);
          localStorage.setItem('thungphim_history', JSON.stringify(history.slice(0, 20)));
        }

      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [slug, episode, activeServerIdx]);

  if (loading || !data || !currentEp) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-[1320px] mx-auto px-4">
        <div className="flex flex-col gap-8">
          
          <div className="space-y-4">
             <nav className="text-gray-500 text-xs flex items-center gap-2 mb-2">
                <Link to="/" className="hover:text-white transition-colors">Trang chủ</Link>
                <span>/</span>
                <Link to={`/movie/${data.movie.slug}`} className="hover:text-white transition-colors">{data.movie.name}</Link>
                <span>/</span>
                <span className="text-red-500 font-bold">Tập {episode}</span>
             </nav>
             <h1 className="text-3xl font-black text-white">
               {data.movie?.name} <span className="text-red-600 ml-2">Tập {episode}</span>
             </h1>
             <p className="text-gray-500 font-medium flex items-center gap-3">
               {data.movie?.origin_name}
               <span className="w-1 h-1 bg-gray-700 rounded-full" />
               <span className="text-xs uppercase bg-gray-800 px-2 py-0.5 rounded border border-gray-700">
                 {data.episodes[activeServerIdx]?.server_name.includes('Lồng Tiếng') ? 'Hà Nội (Lồng Tiếng)' : 'Hà Nội (Vietsub)'}
               </span>
             </p>
          </div>

          {/* Player Container */}
          <div className="w-full bg-black aspect-video rounded-3xl overflow-hidden shadow-2xl border border-gray-800 ring-4 ring-black">
            <iframe
              src={currentEp.link_embed}
              className="w-full h-full"
              frameBorder="0"
              allowFullScreen
            ></iframe>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-10">
              
              {/* Server Selection */}
              <div className="space-y-4">
                 <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest">Chọn Máy Chủ</h3>
                 <div className="flex flex-wrap gap-3">
                   {data.episodes.map((server, sIdx) => {
                     const isDubbed = server.server_name.toLowerCase().includes('lồng tiếng');
                     return (
                       <button
                        key={sIdx}
                        onClick={() => setActiveServerIdx(sIdx)}
                        className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold transition-all border ${
                          activeServerIdx === sIdx 
                            ? 'bg-red-600 text-white border-red-500 shadow-lg shadow-red-600/30' 
                            : 'bg-gray-900 text-gray-400 border-gray-800 hover:border-gray-600'
                        }`}
                       >
                         {isDubbed && (
                           <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" />
                         )}
                         {isDubbed ? 'Hà Nội (Lồng Tiếng)' : `Máy Chủ ${sIdx + 1}`}
                       </button>
                     );
                   })}
                 </div>
              </div>

              {/* Episodes List */}
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                   <h3 className="text-xl font-bold text-white uppercase tracking-widest flex items-center gap-2">
                     <div className="w-1 h-6 bg-red-600" /> Danh Sách Tập
                   </h3>
                </div>
                <div className="bg-gray-900/40 p-6 rounded-3xl border border-gray-800 grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-3">
                  {data.episodes[activeServerIdx]?.server_data?.map((ep, idx) => (
                    <Link
                      key={idx}
                      to={`/watch/${data.movie.slug}/${ep.name}`}
                      className={`py-3 rounded-xl text-center text-sm font-bold transition-all border ${
                        ep.name === episode 
                          ? 'bg-red-600 text-white border-red-500 shadow-lg shadow-red-600/30' 
                          : 'bg-gray-800 text-gray-400 border-gray-700 hover:bg-gray-700 hover:text-white'
                      }`}
                    >
                      {ep.name}
                    </Link>
                  ))}
                </div>
              </div>
              
              <div className="bg-gray-900/20 p-8 rounded-3xl border border-dashed border-gray-800">
                <h4 className="text-white font-bold mb-4">Lưu ý khi xem:</h4>
                <ul className="text-sm text-gray-500 space-y-2 list-disc pl-5">
                   <li>Máy chủ <strong>Hà Nội (Lồng Tiếng)</strong> được tối ưu cho đường truyền Việt Nam.</li>
                   <li>Nếu không thấy bản Lồng Tiếng, hãy kiểm tra các máy chủ khác trong danh sách.</li>
                   <li>Sử dụng trình duyệt Chrome hoặc Safari để có trải nghiệm tốt nhất.</li>
                </ul>
              </div>
            </div>

            <div className="space-y-8">
              <h3 className="text-xl font-bold text-white uppercase tracking-widest flex items-center gap-2">
                <div className="w-1 h-6 bg-yellow-500" /> Đang chiếu
              </h3>
              <div className="bg-gray-900/50 p-6 rounded-3xl border border-gray-800 space-y-6">
                 <div className="flex gap-4">
                    <img src={MovieService.getImageUrl(data.movie?.thumb_url)} className="w-20 h-28 object-cover rounded-xl border border-white/10" alt="thumb" />
                    <div className="space-y-1">
                       <h4 className="text-white font-bold leading-tight line-clamp-2">{data.movie?.name}</h4>
                       <p className="text-gray-500 text-xs">{data.movie?.year}</p>
                       <div className="flex flex-wrap gap-1 pt-1">
                          {data.movie?.category?.slice(0, 2).map(c => (
                            <span key={c.slug} className="text-[10px] bg-gray-800 text-gray-400 px-2 py-0.5 rounded border border-gray-700">{c.name}</span>
                          ))}
                       </div>
                    </div>
                 </div>
                 <div className="text-sm text-gray-400 leading-relaxed line-clamp-4" dangerouslySetInnerHTML={{ __html: data.movie?.content || '' }} />
                 <Link to={`/movie/${data.movie?.slug}`} className="block text-center bg-gray-800 text-white py-3 rounded-xl text-xs font-bold hover:bg-gray-700 transition-all">XEM THÔNG TIN CHI TIẾT</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
