
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { MovieService } from '../services/movieService';
import { Movie } from '../types';
import { MovieCard } from '../components/MovieCard';
import { Logo } from '../components/Logo';

const HeroBanner = ({ movie }: { movie: Movie }) => (
  <div className="relative h-[90vh] w-full overflow-hidden">
    <div className="absolute inset-0">
      <img 
        src={MovieService.getImageUrl(movie.poster_url)} 
        alt={movie.name}
        className="w-full h-full object-cover scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/60 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent" />
    </div>
    
    <div className="relative h-full max-w-[1320px] mx-auto px-4 flex flex-col justify-center items-start pt-20">
      <div className="max-w-2xl space-y-6">
        <div className="flex items-center gap-3">
          <span className="bg-red-600 text-[10px] font-black px-3 py-1.5 rounded text-white uppercase tracking-[0.2em]">
            SIÊU PHẨM HOT
          </span>
          <span className="text-gray-300 font-bold text-sm">{movie.year} • {movie.quality} • {movie.time}</span>
        </div>
        
        <h1 className="text-6xl md:text-8xl font-black text-white leading-[0.9] drop-shadow-2xl uppercase tracking-tighter">
          {movie.name}
        </h1>
        
        <p className="text-lg text-gray-400 line-clamp-3 leading-relaxed drop-shadow max-w-xl">
          {movie.content?.replace(/<[^>]*>?/gm, '') || ''}
        </p>
        
        <div className="flex items-center gap-4 pt-6">
          <Link 
            to={`/movie/${movie.slug}`}
            className="flex items-center gap-3 bg-red-600 hover:bg-red-700 text-white font-black py-4.5 px-10 rounded-xl transition-all hover:scale-105 shadow-2xl shadow-red-600/40 uppercase text-sm tracking-widest"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.333-5.89a1.5 1.5 0 000-2.538L6.3 2.841z" />
            </svg>
            Xem ngay
          </Link>
          <button className="flex items-center gap-3 bg-white/5 hover:bg-white/10 backdrop-blur-xl text-white font-black py-4.5 px-8 rounded-xl transition-all border border-white/10 uppercase text-sm tracking-widest">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
            </svg>
            Yêu thích
          </button>
        </div>
      </div>
    </div>
  </div>
);

export const Home = () => {
  const { type } = useParams<{ type?: string }>();
  const [latestMovies, setLatestMovies] = useState<Movie[]>([]);
  const [featuredSeries, setFeaturedSeries] = useState<Movie[]>([]);
  const [dubbedMovies, setDubbedMovies] = useState<Movie[]>([]);
  const [filterResults, setFilterResults] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchVal, setSearchVal] = useState('');
  const navigate = useNavigate();
  
  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [yearMovies, setYearMovies] = useState<Movie[]>([]);
  const [yearLoading, setYearLoading] = useState(false);
  
  const years = Array.from({ length: 10 }, (_, i) => currentYear - i);

  useEffect(() => {
    const fetchHomeData = async () => {
      setLoading(true);
      try {
        if (!type || type === 'new') {
          const [latestRes, seriesRes, dubbedRes] = await Promise.all([
            MovieService.getLatestMovies(1),
            MovieService.getSeriesMovies(1),
            MovieService.getMoviesByFilter('lang', 'long-tieng', 1)
          ]);
          setLatestMovies(latestRes.items || []);
          setFeaturedSeries(seriesRes || []);
          setDubbedMovies(dubbedRes || []);
          setFilterResults([]);
        } else {
          let results: Movie[] = [];
          if (type === 'long-tieng') {
            results = await MovieService.getMoviesByFilter('lang', 'long-tieng', 1);
          } else if (type === 'single') {
            results = await MovieService.getMoviesByFilter('type', 'phim-le', 1);
          } else if (type === 'series') {
            results = await MovieService.getMoviesByFilter('type', 'phim-bo', 1);
          }
          setFilterResults(results);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchHomeData();
    window.scrollTo(0, 0);
  }, [type]);

  useEffect(() => {
    const fetchYearMovies = async () => {
      if (type && type !== 'new') return;
      setYearLoading(true);
      try {
        const items = await MovieService.getMoviesByYear(selectedYear, 1);
        setYearMovies(items.slice(0, 12));
      } catch (err) {
        console.error(err);
        setYearMovies([]);
      } finally {
        setYearLoading(false);
      }
    };
    fetchYearMovies();
  }, [selectedYear, type]);

  const onHomeSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchVal.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchVal)}`);
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center">
      <div className="flex flex-col items-center gap-8">
        <Logo size="xl" showText={false} className="animate-pulse" />
        <div className="flex flex-col items-center gap-2">
          <div className="w-16 h-1 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-red-600 w-1/2 animate-[loading_1.5s_infinite_ease-in-out]"></div>
          </div>
          <span className="text-[10px] font-black tracking-[0.4em] text-gray-500 uppercase">THUNGPHIM.COM</span>
        </div>
      </div>
      <style>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
      `}</style>
    </div>
  );

  if (type && type !== 'new') {
    const title = type === 'long-tieng' ? 'SIÊU PHẨM LỒNG TIẾNG' : 
                  type === 'single' ? 'PHIM LẺ ĐẶC SẮC' : 
                  type === 'series' ? 'PHIM BỘ ĐANG CHIẾU' : 'KẾT QUẢ LỌC';
    
    return (
      <div className="pt-32 pb-20 min-h-screen">
        <div className="max-w-[1320px] mx-auto px-4">
          <div className="flex items-center gap-5 mb-16">
            <div className={`w-2 h-10 rounded-full ${type === 'long-tieng' ? 'bg-yellow-500 shadow-[0_0_15px_rgba(234,179,8,0.5)]' : 'bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.5)]'}`} />
            <h2 className={`text-4xl font-black tracking-tighter uppercase ${type === 'long-tieng' ? 'text-yellow-500' : 'text-white'}`}>{title}</h2>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-6 gap-y-10">
            {filterResults.map(movie => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#050505]">
      {latestMovies && latestMovies.length > 0 && <HeroBanner movie={latestMovies[0]} />}
      
      <div className="max-w-[1320px] mx-auto px-4 -mt-24 relative z-10 pb-20 space-y-24">
        
        {/* Section Phim Lồng Tiếng - Máy chủ Hà Nội */}
        <section>
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-5">
              <div className="w-2 h-10 bg-gradient-to-b from-yellow-400 to-amber-600 rounded-full shadow-[0_0_20px_rgba(245,158,11,0.4)]" />
              <div>
                <h2 className="text-3xl font-black text-white tracking-tighter uppercase flex items-center gap-3">
                  SIÊU PHẨM LỒNG TIẾNG
                  <span className="text-[10px] bg-yellow-500/10 text-yellow-500 border border-yellow-500/30 px-3 py-1 rounded-full tracking-widest font-black">HANOI SERVER</span>
                </h2>
                <p className="text-xs text-gray-500 font-bold mt-1 tracking-widest uppercase">Máy chủ Hà Nội tốc độ cao - Thuyết minh chuyên nghiệp</p>
              </div>
            </div>
            <Link to="/filter/long-tieng" className="group flex items-center gap-2 text-yellow-500 font-black text-xs uppercase tracking-widest bg-yellow-500/5 hover:bg-yellow-500/10 px-6 py-3 rounded-xl transition-all border border-yellow-500/10">
              XEM TẤT CẢ
              <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-6 gap-y-10">
            {dubbedMovies && dubbedMovies.slice(0, 12).map(movie => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-5">
              <div className="w-2 h-10 bg-red-600 rounded-full shadow-[0_0_20px_rgba(220,38,38,0.4)]" />
              <h2 className="text-3xl font-black text-white tracking-tighter uppercase">MỚI CẬP NHẬT</h2>
            </div>
            <Link to="/filter/new" className="text-gray-500 hover:text-white font-black text-xs uppercase tracking-widest transition-colors">XEM TẤT CẢ</Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-6 gap-y-10">
            {latestMovies && latestMovies.slice(0, 12).map(movie => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-5">
              <div className="w-2 h-10 bg-purple-600 rounded-full shadow-[0_0_20px_rgba(147,51,234,0.4)]" />
              <h2 className="text-3xl font-black text-white tracking-tighter uppercase">PHIM BỘ ĐẶC SẮC</h2>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-6 gap-y-10">
            {featuredSeries && featuredSeries.slice(0, 12).map(movie => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>
        </section>

        <section className="bg-white/5 p-12 rounded-[40px] border border-white/5 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/10 blur-[100px] -mr-32 -mt-32 rounded-full" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-yellow-500/5 blur-[100px] -ml-32 -mb-32 rounded-full" />
          
          <div className="max-w-4xl mx-auto text-center space-y-8 relative z-10">
            <h2 className="text-4xl font-black text-white tracking-tighter">BẠN ĐANG TÌM KIẾM ĐIỀU GÌ?</h2>
            
            <form onSubmit={onHomeSearch} className="max-w-2xl mx-auto relative group">
              <input 
                type="text" 
                placeholder="Tìm phim, thể loại, diễn viên..."
                value={searchVal}
                onChange={(e) => setSearchVal(e.target.value)}
                className="w-full bg-black/50 border border-white/10 text-white rounded-2xl py-5 px-8 pr-16 focus:outline-none focus:ring-2 focus:ring-red-600/50 text-lg transition-all focus:bg-black group-hover:border-white/20 shadow-2xl"
              />
              <button type="submit" className="absolute right-4 top-3.5 bg-red-600 hover:bg-red-700 text-white p-2.5 rounded-xl transition-all shadow-lg shadow-red-600/20">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>
            </form>

            <div className="flex flex-wrap justify-center gap-4 pt-4">
              {['Hành Động', 'Tình Cảm', 'Cổ Trang', 'Hài Hước', 'Viễn Tưởng', 'Kinh Dị', 'Hoạt Hình'].map(cat => (
                <button 
                  key={cat} 
                  onClick={() => navigate(`/search?q=${cat}`)} 
                  className="bg-white/5 hover:bg-white/10 text-gray-300 font-bold px-8 py-3 rounded-2xl transition-all border border-white/10 text-sm tracking-widest hover:border-red-600/50"
                >
                  {cat.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
