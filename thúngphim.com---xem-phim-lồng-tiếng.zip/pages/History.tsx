
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export const History = () => {
  const [history, setHistory] = useState<any[]>([]);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('thungphim_history') || '[]');
    setHistory(data);
  }, []);

  const clearHistory = () => {
    localStorage.removeItem('thungphim_history');
    setHistory([]);
  };

  return (
    <div className="pt-32 pb-20 min-h-screen">
      <div className="max-w-[1320px] mx-auto px-4">
        <div className="flex items-center justify-between mb-12">
          <h2 className="text-3xl font-black text-white">LỊCH SỬ XEM</h2>
          {history.length > 0 && (
            <button onClick={clearHistory} className="text-gray-500 hover:text-red-500 text-sm font-bold transition-colors">
              XÓA TẤT CẢ
            </button>
          )}
        </div>

        {history.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {history.map((item, idx) => (
              <Link key={idx} to={`/watch/${item.slug}/${item.episode}`} className="group block relative rounded-xl overflow-hidden bg-gray-900">
                <div className="aspect-[2/3] relative">
                  <img src={item.poster} className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                     <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center">
                        <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.333-5.89a1.5 1.5 0 000-2.538L6.3 2.841z" /></svg>
                     </div>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
                     <h3 className="text-white font-bold truncate text-sm">{item.name}</h3>
                     <p className="text-red-500 text-xs font-bold mt-1">Đang xem tập {item.episode}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 text-gray-500">
            Bạn chưa xem bộ phim nào gần đây.
          </div>
        )}
      </div>
    </div>
  );
};
