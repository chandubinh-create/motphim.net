
import { Movie, Episode } from '../types';

const API_BASE = 'https://phimapi.com';
const IMG_PROXY = 'https://phimapi.com/image.php?url=';

export const MovieService = {
  async getLatestMovies(page: number = 1): Promise<{ items: Movie[]; pathImage: string }> {
    try {
      const res = await fetch(`${API_BASE}/danh-sach/phim-moi-cap-nhat?page=${page}`);
      const data = await res.json();
      return {
        items: data.items || [],
        pathImage: ''
      };
    } catch (error) {
      console.error("Fetch latest movies error:", error);
      return { items: [], pathImage: '' };
    }
  },

  async getSeriesMovies(page: number = 1): Promise<Movie[]> {
    try {
      const res = await fetch(`${API_BASE}/v1/api/danh-sach/phim-bo?page=${page}`);
      const data = await res.json();
      return data.data?.items || [];
    } catch (error) {
      console.error("Fetch series movies error:", error);
      return [];
    }
  },

  async getMoviesByFilter(filterType: string, value: string, page: number = 1): Promise<Movie[]> {
    try {
      // Sử dụng API tổng hợp với tham số filter
      // filterType có thể là 'sort_lang', 'category', 'country', vv.
      let url = `${API_BASE}/v1/api/danh-sach/phim-moi-cap-nhat?page=${page}`;
      
      if (filterType === 'lang') {
        url = `${API_BASE}/v1/api/tim-kiem?keyword=${value === 'long-tieng' ? 'Lồng Tiếng' : 'Vietsub'}&page=${page}`;
      } else if (filterType === 'type') {
        url = `${API_BASE}/v1/api/danh-sach/${value}?page=${page}`;
      }

      const res = await fetch(url);
      const data = await res.json();
      return data.data?.items || data.items || [];
    } catch (error) {
      console.error("Filter movies error:", error);
      return [];
    }
  },

  async getMoviesByYear(year: number, page: number = 1): Promise<Movie[]> {
    try {
      const res = await fetch(`${API_BASE}/v1/api/nam/${year}?page=${page}`);
      const data = await res.json();
      return data.data?.items || [];
    } catch (error) {
      console.error(`Fetch movies for year ${year} error:`, error);
      return [];
    }
  },

  async getMovieDetail(slug: string): Promise<{ movie: Movie; episodes: Episode[] }> {
    try {
      const res = await fetch(`${API_BASE}/phim/${slug}`);
      const data = await res.json();
      return {
        movie: data.movie || {},
        episodes: data.episodes || []
      };
    } catch (error) {
      console.error("Fetch movie detail error:", error);
      throw error;
    }
  },

  async searchMovies(keyword: string, page: number = 1): Promise<Movie[]> {
    try {
      const res = await fetch(`${API_BASE}/v1/api/tim-kiem?keyword=${encodeURIComponent(keyword)}&page=${page}`);
      const data = await res.json();
      return data.data?.items || [];
    } catch (error) {
      console.error("Search movies error:", error);
      return [];
    }
  },

  getImageUrl(path: string): string {
    if (!path) return 'https://placehold.co/600x400?text=No+Image';
    return `${IMG_PROXY}${encodeURIComponent(path)}`;
  }
};
