
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const GeminiService = {
  async summarizeMovie(movieName: string, description: string): Promise<string> {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Bạn là một biên tập viên phim chuyên nghiệp của ThúngPhim.com. Hãy tóm tắt ngắn gọn, lôi cuốn nội dung phim "${movieName}" dựa trên mô tả sau (tối đa 150 chữ): ${description.replace(/<[^>]*>?/gm, '')}`,
        config: {
          temperature: 0.7,
        }
      });
      return response.text || description;
    } catch (error) {
      console.error("Gemini Error:", error);
      return description;
    }
  }
};
