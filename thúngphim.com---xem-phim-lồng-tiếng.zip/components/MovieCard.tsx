
import React from 'react';
import { Link } from 'react-router-dom';
import { Movie } from '../types';
import { MovieService } from '../services/movieService';

interface MovieCardProps {
  movie: Movie;
}

export const MovieCard: React.FC<MovieCardProps> = ({ movie }) => {
  // Nhận diện bản lồng tiếng từ thuộc tính lang hoặc name
  const isDubbed = movie.lang?.includes('Lồng') || movie.name?.toLowerCase().includes('lồng tiếng');
  
  return (
    <Link 
      to={`/movie/${movie.slug}`}
      className="group block relative rounded-lg overflow-hidden bg-gray-900 shadow-xl transition-all duration-300 hover:-translate-y-2 hover:shadow-red-900/10"
    >
      <div className="aspect-[2/3] relative overflow-hidden">
        <img 
          src={MovieService.getImageUrl(movie.poster_url || movie.thumb_url)} 
          alt={movie.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
           <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center shadow-lg shadow-red-600/50">
              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.333-5.89a1.5 1.5 0 000-2.538L6.3 2.841z" />
              </svg>
           </div>
        </div>
        
        {/* Badges - Nơi hiển thị nhãn Lồng Tiếng/Vietsub */}
        <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
          {movie.quality && movie.quality !== 'HD' && (
            <span className="bg-red-600 text-[10px] font-bold px-2 py-0.5 rounded text-white uppercase shadow-sm">
              {movie.quality}
            </span>
          )}
          {isDubbed ? (
            <span className="bg-gradient-to-r from-yellow-600 to-amber-400 text-[10px] font-black px-2 py-0.5 rounded text-black uppercase shadow-lg shadow-yellow-600/20">
              Lồng Tiếng
            </span>
          ) : movie.lang && (
            <span className="bg-blue-600 text-[10px] font-bold px-2 py-0.5 rounded text-white uppercase shadow-sm">
              {movie.lang.includes('Vietsub') ? 'Vietsub' : movie.lang}
            </span>
          )}
        </div>
        
        {movie.episode_current && (
          <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-md text-[10px] font-medium px-2 py-0.5 rounded border border-white/10 text-gray-300">
            {movie.episode_current}
          </div>
        )}
      </div>
      
      <div className="p-3">
        <h3 className="text-sm font-bold text-white truncate group-hover:text-red-500 transition-colors">
          {movie.name}
        </h3>
        <p className="text-xs text-gray-500 truncate mt-1">
          {movie.origin_name} ({movie.year})
        </p>
      </div>
    </Link>
  );
};
