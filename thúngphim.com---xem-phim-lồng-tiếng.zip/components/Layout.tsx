
import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Logo } from './Logo';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileSearchOpen(false);
  }, [location]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
      setIsMobileSearchOpen(false);
    }
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-black/95 backdrop-blur-md py-3 shadow-2xl' : 'bg-gradient-to-b from-black/90 via-black/40 to-transparent py-6'}`}>
      <div className="max-w-[1320px] mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-10">
          <Link to="/" className="group">
            <Logo size="md" />
          </Link>
          
          <nav className="hidden lg:flex items-center gap-6 text-xs font-black tracking-widest text-gray-400">
            <Link to="/" className={`hover:text-white transition-colors ${location.pathname === '/' ? 'text-white border-b-2 border-red-600 pb-1' : ''}`}>TRANG CHỦ</Link>
            <Link to="/filter/series" className={`hover:text-white transition-colors ${location.pathname.includes('series') ? 'text-white border-b-2 border-red-600 pb-1' : ''}`}>PHIM BỘ</Link>
            <Link to="/filter/single" className={`hover:text-white transition-colors ${location.pathname.includes('single') ? 'text-white border-b-2 border-red-600 pb-1' : ''}`}>PHIM LẺ</Link>
            <Link to="/filter/long-tieng" className="text-yellow-500 hover:text-yellow-400 flex items-center gap-1.5 transition-colors">
              <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full animate-pulse"></span>
              LỒNG TIẾNG
            </Link>
            <Link to="/search" className={`hover:text-white transition-colors ${location.pathname === '/search' ? 'text-white border-b-2 border-red-600 pb-1' : ''}`}>TÌM KIẾM</Link>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <form onSubmit={handleSearch} className="relative hidden md:block">
            <input 
              type="text" 
              placeholder="Tìm phim, diễn viên..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white/5 border border-white/10 text-white rounded-xl py-2.5 px-6 pl-12 focus:outline-none focus:ring-2 focus:ring-red-600/50 w-72 transition-all focus:bg-white/10 text-sm font-medium"
            />
            <svg className="absolute left-4 top-3 w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </form>
          
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsMobileSearchOpen(!isMobileSearchOpen)}
              className="md:hidden w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-400"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
            <Link to="/history" className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-all">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </Link>
          </div>
        </div>
      </div>

      {isMobileSearchOpen && (
        <div className="absolute top-full left-0 right-0 bg-black/95 p-4 md:hidden border-t border-white/10 animate-in slide-in-from-top duration-300">
          <form onSubmit={handleSearch} className="relative">
            <input 
              type="text" 
              autoFocus
              placeholder="Nhập tên phim cần tìm..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/10 border border-white/20 text-white rounded-xl py-4 px-6 focus:outline-none"
            />
            <button type="submit" className="absolute right-4 top-3 bg-red-600 p-1.5 rounded-lg">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
          </form>
        </div>
      )}
    </header>
  );
};

const SocialIcons = ({ size = "w-5 h-5", className = "" }) => (
  <div className={`flex items-center gap-4 ${className}`}>
    <a href="#" className="text-gray-500 hover:text-[#1877F2] transition-colors" title="Facebook">
      <svg className={size} fill="currentColor" viewBox="0 0 24 24">
        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
      </svg>
    </a>
    <a href="#" className="text-gray-500 hover:text-[#FF0000] transition-colors" title="YouTube">
      <svg className={size} fill="currentColor" viewBox="0 0 24 24">
        <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
      </svg>
    </a>
    <a href="#" className="text-gray-500 hover:text-white transition-colors" title="TikTok">
      <svg className={size} fill="currentColor" viewBox="0 0 24 24">
        <path d="M12.525.02c1.31 0 2.59.35 3.72 1.01a7.22 7.22 0 0 1 2.57-1.03 1.05 1.05 0 0 1 1.18.96 11.23 11.23 0 0 0 1.25 5.25c.18.33.15.75-.1 1.03a6.83 6.83 0 0 1-5.18 2.08c-.14 0-.27-.01-.4-.03V16.5c0 4.14-3.36 7.5-7.5 7.5S.975 20.64.975 16.5s3.36-7.5 7.5-7.5c.34 0 .67.02 1 .07V12.1c-.33-.06-.66-.1-1-.1a4.5 4.5 0 1 0 4.5 4.5V0h.55z"/>
      </svg>
    </a>
    <a href="#" className="text-gray-500 hover:text-[#0088cc] transition-colors" title="Telegram">
      <svg className={size} fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.13-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
      </svg>
    </a>
  </div>
);

const Footer = () => (
  <footer className="bg-[#020202] border-t border-white/5 pt-20 pb-10 mt-20">
    <div className="max-w-[1320px] mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-16">
        <div className="col-span-1 md:col-span-1 space-y-6">
          <Link to="/">
            <Logo size="md" />
          </Link>
          <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
            ThúngPhim.com - Hệ thống xem phim trực tuyến hiện đại, máy chủ Hà Nội lồng tiếng Việt tốc độ cao, hoàn toàn miễn phí cho người dùng Việt.
          </p>
        </div>
        <div>
          <h4 className="text-white font-black text-[10px] uppercase tracking-[0.2em] mb-8 opacity-50">Danh Mục</h4>
          <ul className="space-y-4 text-gray-500 text-sm font-bold">
            <li><Link to="/" className="hover:text-red-500 transition-colors">Trang Chủ</Link></li>
            <li><Link to="/filter/series" className="hover:text-red-500 transition-colors">Phim Bộ Mới</Link></li>
            <li><Link to="/filter/long-tieng" className="hover:text-yellow-500 transition-colors text-yellow-500/80">Phim Lồng Tiếng</Link></li>
            <li><Link to="/filter/single" className="hover:text-red-500 transition-colors">Phim Lẻ Chiếu Rạp</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-black text-[10px] uppercase tracking-[0.2em] mb-8 opacity-50">Trợ Giúp</h4>
          <ul className="space-y-4 text-gray-500 text-sm font-bold">
            <li><a href="#" className="hover:text-white transition-colors">Điều Khoản Dịch Vụ</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Chính Sách Quyền Riêng Tư</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Yêu Cầu Gỡ Phim</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Liên Hệ Kỹ Thuật</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-black text-[10px] uppercase tracking-[0.2em] mb-8 opacity-50">Kết Nối Với Chúng Tôi</h4>
          <SocialIcons size="w-6 h-6" className="mb-8" />
          <p className="text-[10px] text-gray-600 mt-6 font-bold uppercase tracking-widest">Version 2.0.0 (Hanoi Stable)</p>
        </div>
      </div>
      
      {/* Last Row of Footer */}
      <div className="mt-20 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-gray-600 text-[10px] font-bold tracking-[0.3em] uppercase">
        <div className="flex flex-col md:flex-row items-center gap-4 md:gap-8">
          <span>&copy; 2026 THÚNGPHIM.COM. ALL RIGHTS RESERVED.</span>
          <SocialIcons size="w-4 h-4" />
        </div>
        <div className="flex gap-6 items-center">
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full shadow-[0_0_8px_rgba(34,197,94,0.5)]"></span> 
              SERVERS STATUS: NORMAL
            </span>
            <span className="hidden md:block opacity-30">|</span>
            <span className="hidden md:block">POWERED BY HANOI CLOUD</span>
        </div>
      </div>
    </div>
  </footer>
);

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-[#050505]">
      <Header />
      <main className="flex-grow pt-0">
        {children}
      </main>
      <Footer />
    </div>
  );
};
