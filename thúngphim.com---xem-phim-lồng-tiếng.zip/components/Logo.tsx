
import React from 'react';

interface LogoProps {
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const Logo: React.FC<LogoProps> = ({ className = '', showText = true, size = 'md' }) => {
  const sizeMap = {
    sm: 'h-6',
    md: 'h-10',
    lg: 'h-16',
    xl: 'h-24'
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className={`${sizeMap[size]} aspect-square relative group`}>
        {/* Lớp nền hiệu ứng tỏa sáng */}
        <div className="absolute inset-0 bg-red-600 rounded-full blur-lg opacity-20 group-hover:opacity-40 transition-opacity"></div>
        
        {/* SVG Icon chiếc Thúng cách điệu */}
        <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 filter drop-shadow-lg">
          {/* Vòng thúng */}
          <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="8" className="text-red-600" />
          <circle cx="50" cy="50" r="35" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" className="text-yellow-500 opacity-50" />
          
          {/* Nút Play bên trong */}
          <path 
            d="M42 35L65 50L42 65V35Z" 
            fill="white" 
            className="drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]"
          />
          
          {/* Các tia nan thúng */}
          {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
            <rect 
              key={deg}
              x="48" y="2" width="4" height="8" 
              rx="2"
              fill="currentColor"
              className="text-red-600"
              transform={`rotate(${deg} 50 50)`}
            />
          ))}
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col -space-y-1">
          <span className="text-xl md:text-2xl font-black tracking-tighter text-white uppercase leading-none">
            THÚNG<span className="text-red-600 font-black">PHIM</span>
          </span>
          <span className="text-[8px] font-black tracking-[0.4em] text-yellow-500 uppercase ml-0.5">.COM</span>
        </div>
      )}
    </div>
  );
};
