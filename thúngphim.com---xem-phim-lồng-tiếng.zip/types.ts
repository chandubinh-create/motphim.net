
export interface Movie {
  _id: string;
  name: string;
  origin_name: string;
  content: string;
  type: 'single' | 'series';
  status: string;
  thumb_url: string;
  poster_url: string;
  is_copyright: boolean;
  sub_docquyen: boolean;
  chieurap: boolean;
  trailer_url: string;
  time: string;
  episode_current: string;
  episode_total: string;
  quality: string;
  lang: string;
  notify: string;
  showtimes: string;
  slug: string;
  year: number;
  actor: string[];
  director: string[];
  category: { name: string; slug: string }[];
  country: { name: string; slug: string }[];
}

export interface Episode {
  server_name: string;
  server_data: {
    name: string;
    slug: string;
    filename: string;
    link_embed: string;
    link_m3u8: string;
  }[];
}

export interface WatchHistory {
  movieId: string;
  movieName: string;
  episodeName: string;
  time: number; // in seconds
  duration: number;
  updatedAt: number;
  poster: string;
  slug: string;
}

export interface UserState {
  favorites: string[]; // movie slugs
  history: WatchHistory[];
}
