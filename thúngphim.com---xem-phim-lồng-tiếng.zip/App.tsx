
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { MovieDetail } from './pages/MovieDetail';
import { Watch } from './pages/Watch';
import { Search } from './pages/Search';
import { History } from './pages/History';

function App() {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/movie/:slug" element={<MovieDetail />} />
          <Route path="/watch/:slug/:episode" element={<Watch />} />
          <Route path="/search" element={<Search />} />
          <Route path="/history" element={<History />} />
          <Route path="/favorites" element={<History />} /> {/* Using history as mock favorites for now */}
          <Route path="/filter/:type" element={<Home />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
}

export default App;
